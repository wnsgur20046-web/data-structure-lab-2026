#include "mainwindow.h"
#include "mapwidget.h"

#include <QWidget>
#include <QLabel>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QScrollArea>
#include <QMessageBox>
#include <QFrame>
#include <QLocale>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setWindowTitle("항공권 예매 시스템 (그래프 자료구조)");
    resize(1180, 540);

    buildGraph();   // 1) 그래프(데이터)부터 구성
    buildUI();      // 2) 그 다음 화면(UI) 구성
}

MainWindow::~MainWindow() {}

// ----------------------------------------------------
// 1) 그래프 데이터 만들기 (공항=노드, 항공편=간선)
//    addAirport(코드, 이름, 위도, 경도, 표시보정X, 표시보정Y)
// ----------------------------------------------------
void MainWindow::buildGraph()
{
    graph.addAirport("ICN", "인천",         37.46, 126.44, -14, -2);  // 0
    graph.addAirport("GMP", "김포",         37.56, 126.80,  10, -14); // 1
    graph.addAirport("CJU", "제주",         33.51, 126.49,  -2,  16); // 2
    graph.addAirport("PUS", "부산",         35.18, 128.94,  16,   6); // 3
    graph.addAirport("NRT", "도쿄",         35.77, 140.39,   0,   0); // 4
    graph.addAirport("PEK", "베이징",       40.08, 116.58,  -6,  -6); // 5
    graph.addAirport("PVG", "상하이",       31.14, 121.81,   4,   6); // 6
    graph.addAirport("HKG", "홍콩",         22.31, 113.91,  -2,   6); // 7
    graph.addAirport("SIN", "싱가포르",      1.36, 103.99,   0,   0); // 8
    graph.addAirport("LHR", "런던",         51.47,  -0.45,   0,   0); // 9
    graph.addAirport("JFK", "뉴욕",         40.64, -73.78,   0,   0); // 10
    graph.addAirport("LAX", "로스앤젤레스",  33.94, -118.41,  0,   0); // 11

    // ----- 국내선 -----
    graph.addFlight(2, 1, "LJ302",  "진에어",   85000,  70);
    graph.addFlight(1, 2, "LJ301",  "진에어",   80000,  70);
    graph.addFlight(2, 3, "LJ502",  "진에어",   75000,  50);
    graph.addFlight(3, 2, "LJ501",  "진에어",   70000,  50);
    graph.addFlight(1, 3, "KE1234", "대한항공", 68000,  55);
    graph.addFlight(3, 1, "KE1235", "대한항공", 68000,  55);
    graph.addFlight(0, 2, "7C101",  "제주항공", 60000,  65);
    graph.addFlight(2, 0, "7C102",  "제주항공", 60000,  65);

    // ----- 인천(허브) 국제선 -----
    graph.addFlight(0, 4,  "OZ102", "아시아나", 320000,  145);
    graph.addFlight(4, 0,  "OZ101", "아시아나", 310000,  150);
    graph.addFlight(0, 5,  "OZ333", "아시아나", 280000,  120);
    graph.addFlight(5, 0,  "OZ334", "아시아나", 280000,  120);
    graph.addFlight(0, 6,  "KE893", "대한항공", 250000,   95);
    graph.addFlight(6, 0,  "KE894", "대한항공", 250000,   95);
    graph.addFlight(0, 7,  "KE607", "대한항공", 350000,  220);
    graph.addFlight(7, 0,  "KE608", "대한항공", 350000,  220);
    graph.addFlight(0, 8,  "OZ751", "아시아나", 480000,  385);
    graph.addFlight(8, 0,  "OZ752", "아시아나", 470000,  385);
    graph.addFlight(0, 9,  "KE907", "대한항공", 1250000, 740);
    graph.addFlight(9, 0,  "KE908", "대한항공", 1300000, 720);
    graph.addFlight(0, 10, "KE085", "대한항공", 1850000, 840);
    graph.addFlight(10, 0, "KE086", "대한항공", 1920000, 880);
    graph.addFlight(0, 11, "KE017", "대한항공", 1500000, 660);
    graph.addFlight(11, 0, "KE018", "대한항공", 1550000, 720);

    // ----- 기타 국제선 -----
    graph.addFlight(4, 10, "JL006",  "일본항공",     1450000, 780);
    graph.addFlight(10, 4, "JL005",  "일본항공",     1510000, 800);
    graph.addFlight(4, 11, "JL062",  "일본항공",     1300000, 600);
    graph.addFlight(11, 4, "JL061",  "일본항공",     1320000, 610);
    graph.addFlight(7, 8,  "CX715",  "캐세이",       320000,  240);
    graph.addFlight(8, 7,  "CX716",  "캐세이",       320000,  240);
    graph.addFlight(6, 7,  "CX365",  "캐세이",       180000,  150);
    graph.addFlight(7, 6,  "CX366",  "캐세이",       180000,  150);
    graph.addFlight(9, 10, "BA178",  "영국항공",     900000,  450);
    graph.addFlight(10, 9, "BA177",  "영국항공",     950000,  430);
    graph.addFlight(5, 6,  "CA1234", "중국국제항공", 120000,  130);
    graph.addFlight(6, 5,  "CA1235", "중국국제항공", 120000,  130);
    graph.addFlight(1, 4,  "JL092",  "일본항공",     290000,  135);
    graph.addFlight(4, 1,  "JL091",  "일본항공",     300000,  135);
}

// ----------------------------------------------------
// 2) 화면(UI) 구성
//    [ 지도 | 항공편 패널 ]  +  아래쪽 안내문
// ----------------------------------------------------
void MainWindow::buildUI()
{
    QWidget* central = new QWidget(this);
    setCentralWidget(central);

    QVBoxLayout* mainV = new QVBoxLayout(central);
    QHBoxLayout* topH  = new QHBoxLayout();

    // ----- 왼쪽: 지도 위젯 -----
    mapWidget = new MapWidget(&graph);
    mapWidget->setOnAirportClicked([this](int i) { showAirport(i); });
    topH->addWidget(mapWidget, 0, Qt::AlignTop);

    // ----- 오른쪽: 항공편 정보 패널 -----
    QWidget*     rightPanel  = new QWidget;
    QVBoxLayout* rightLayout = new QVBoxLayout(rightPanel);

    titleLabel = new QLabel("<h2>공항을 클릭하세요</h2>");
    hintLabel  = new QLabel("지도에서 공항(점)을 클릭하세요.");
    hintLabel->setStyleSheet("color:#666;");
    rightLayout->addWidget(titleLabel);
    rightLayout->addWidget(hintLabel);

    QScrollArea* scroll = new QScrollArea;
    scroll->setWidgetResizable(true);
    scroll->setFrameShape(QFrame::NoFrame);
    QWidget* infoContainer = new QWidget;
    infoLayout = new QVBoxLayout(infoContainer);
    infoLayout->setAlignment(Qt::AlignTop);
    scroll->setWidget(infoContainer);
    rightLayout->addWidget(scroll, 1);

    rightPanel->setMinimumWidth(360);
    topH->addWidget(rightPanel, 1);

    mainV->addLayout(topH, 1);

    // ----- 아래쪽 안내문 -----
    QLabel* footer = new QLabel("공항 노드를 클릭하면 출발/도착 항공편이 표시됩니다");
    footer->setAlignment(Qt::AlignCenter);
    footer->setStyleSheet("color:#444; padding:6px; background:#eef1f4;");
    mainV->addWidget(footer);
}

// ----------------------------------------------------
// 공항 클릭 시: 출발 항공편(인접 리스트) + 도착 항공편(역방향)을 표시
// ----------------------------------------------------
void MainWindow::showAirport(int v)
{
    mapWidget->setSelected(v);

    const Airport& ap = graph.at(v);
    titleLabel->setText(QString("<h2>%1 (%2)</h2>").arg(ap.name, ap.code));
    hintLabel->setText("마음에 드는 항공편을 클릭하면 예매됩니다.");

    clearInfo();

    // 항공편 버튼 1개를 만들어 목록에 추가하는 도우미
    auto addFlightButton =
        [this](const QString& text, int fromIdx, const Flight& f) {
            QPushButton* b = new QPushButton(text);
            b->setMinimumHeight(50);
            b->setStyleSheet("QPushButton{ text-align:left; padding:8px; }");
            connect(b, &QPushButton::clicked, this, [this, fromIdx, f]() {
                bookFlight(fromIdx, f);
            });
            infoLayout->addWidget(b);
        };

    // 섹션 제목 도우미
    auto addHeader = [this](const QString& t) {
        QLabel* h = new QLabel(QString("<b style='color:#1769e0'>%1</b>").arg(t));
        h->setStyleSheet("margin-top:8px;");
        infoLayout->addWidget(h);
    };

    // ----- 출발 항공편 (이 공항의 인접 리스트) -----
    const std::vector<Flight>& deps = ap.flights;
    addHeader(QString("출발 항공편 (%1편)").arg((int)deps.size()));
    if (deps.empty())
        infoLayout->addWidget(new QLabel("  출발 항공편이 없습니다."));
    for (const Flight& f : deps) {
        const Airport& dest = graph.at(f.to);
        QString text = QString("[%1] %2   →   %3 (%4)\n%5 · %6")
            .arg(f.flightNo, f.airline, dest.code, dest.name,
                 priceText(f.price), timeText(f.minutes));
        addFlightButton(text, v, f);
    }

    // ----- 도착 항공편 (v 로 들어오는 간선들) -----
    std::vector<std::pair<int, Flight> > arrs = graph.arrivalsTo(v);
    addHeader(QString("도착 항공편 (%1편)").arg((int)arrs.size()));
    if (arrs.empty())
        infoLayout->addWidget(new QLabel("  도착 항공편이 없습니다."));
    for (size_t k = 0; k < arrs.size(); ++k) {
        int from = arrs[k].first;
        const Flight& f = arrs[k].second;
        const Airport& origin = graph.at(from);
        QString text = QString("[%1] %2   ←   %3 (%4)\n%5 · %6")
            .arg(f.flightNo, f.airline, origin.code, origin.name,
                 priceText(f.price), timeText(f.minutes));
        addFlightButton(text, from, f);
    }

    infoLayout->addStretch();
}

// ----------------------------------------------------
// 항공편 클릭 시: "예매 완료" 메시지
// ----------------------------------------------------
void MainWindow::bookFlight(int fromIndex, const Flight& f)
{
    const Airport& from = graph.at(fromIndex);
    const Airport& to   = graph.at(f.to);

    QString msg = QString(
        "예매가 완료되었습니다!\n\n"
        "항공편: %1 (%2)\n"
        "구간: %3 → %4\n"
        "가격: %5\n"
        "소요 시간: %6")
        .arg(f.flightNo, f.airline, from.code, to.code,
             priceText(f.price), timeText(f.minutes));

    QMessageBox::information(this, "예매 완료", msg);
}

// 오른쪽 목록 비우기
void MainWindow::clearInfo()
{
    QLayoutItem* item;
    while ((item = infoLayout->takeAt(0)) != nullptr) {
        if (item->widget()) item->widget()->deleteLater();
        delete item;
    }
}

// 가격: 85000 -> "₩85,000"
QString MainWindow::priceText(int won) const
{
    return "₩" + QLocale(QLocale::Korean).toString(won);
}

// 시간: 145 -> "2시간 25분"
QString MainWindow::timeText(int minutes) const
{
    return QString("%1시간 %2분").arg(minutes / 60).arg(minutes % 60);
}
