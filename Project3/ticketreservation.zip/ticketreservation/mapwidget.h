#ifndef MAPWIDGET_H
#define MAPWIDGET_H

#include <QWidget>
#include <QPainter>
#include <QPushButton>
#include <QPointF>
#include <QFont>
#include <functional>

#include "graph.h"
#include "worldmap_data.h"   // loadWorldMap()

// 지도 표시 크기 (등장방형 도법: 가로:세로 = 2:1)
static const int MAP_W = 760;
static const int MAP_H = 380;

// ============================================================
//   MapWidget : 세계지도(배경) + 항로(간선) + 공항(노드)를 그리는 위젯
//   - 노드 위에 투명 버튼을 올려 클릭을 처리
//   - paintEvent 에서 지도/항로/노드를 직접 그림
// ============================================================
class MapWidget : public QWidget {
public:
    MapWidget(const Graph* g, QWidget* parent = nullptr)
        : QWidget(parent), graph(g), selected(-1)
    {
        mapPixmap = loadWorldMap();      // base64로 내장된 지도 로드
        setFixedSize(MAP_W, MAP_H);
        createClickButtons();            // 노드 클릭용 투명 버튼 생성
    }

    // 공항이 클릭되면 호출될 콜백 등록
    void setOnAirportClicked(std::function<void(int)> cb) { onClick = cb; }

    // 선택된 공항을 바꾸고 다시 그림
    void setSelected(int index) { selected = index; update(); }

protected:
    void paintEvent(QPaintEvent*) override {
        QPainter p(this);
        p.setRenderHint(QPainter::Antialiasing);

        // 1) 배경 지도
        if (!mapPixmap.isNull())
            p.drawPixmap(rect(), mapPixmap);
        else
            p.fillRect(rect(), QColor("#a9c9e6"));

        // 2) 항로(간선) 그리기 — 연결된 공항들을 선으로 이음
        p.setPen(QPen(QColor(40, 80, 140, 110), 1.0));
        for (int u = 0; u < graph->size(); ++u) {
            QPointF pu = nodePos(u);
            for (const Flight& f : graph->at(u).flights)
                p.drawLine(pu, nodePos(f.to));
        }

        // 3) 공항(노드) 그리기
        for (int i = 0; i < graph->size(); ++i) {
            QPointF c = nodePos(i);
            bool sel = (i == selected);

            p.setPen(QPen(Qt::white, 2));
            p.setBrush(sel ? QColor("#ff9800") : QColor("#1769e0"));
            qreal r = sel ? 8.0 : 6.0;
            p.drawEllipse(c, r, r);

            // 코드 라벨
            QFont font = p.font();
            font.setPointSize(8);
            font.setBold(true);
            p.setFont(font);
            p.setPen(QColor(20, 20, 20));
            p.drawText(QPointF(c.x() + 9, c.y() - 6), graph->at(i).code);
        }
    }

private:
    // 위도/경도 -> 지도상의 픽셀 좌표 (등장방형 도법)
    QPointF nodePos(int i) const {
        const Airport& a = graph->at(i);
        qreal x = (a.lon + 180.0) / 360.0 * MAP_W + a.nudgeX;
        qreal y = (90.0 - a.lat) / 180.0 * MAP_H + a.nudgeY;
        return QPointF(x, y);
    }

    // 각 노드 위치에 투명한 클릭 버튼을 올려 둠
    void createClickButtons() {
        for (int i = 0; i < graph->size(); ++i) {
            QPointF c = nodePos(i);
            const int s = 26;
            QPushButton* b = new QPushButton(this);
            b->setGeometry(int(c.x() - s / 2), int(c.y() - s / 2), s, s);
            b->setCursor(Qt::PointingHandCursor);
            b->setToolTip(graph->at(i).name + " (" + graph->at(i).code + ")");
            b->setStyleSheet("QPushButton{background:transparent;border:none;}");
            connect(b, &QPushButton::clicked, this, [this, i]() {
                if (onClick) onClick(i);
            });
        }
    }

    const Graph* graph;
    QPixmap      mapPixmap;
    int          selected;
    std::function<void(int)> onClick;
};

#endif // MAPWIDGET_H
