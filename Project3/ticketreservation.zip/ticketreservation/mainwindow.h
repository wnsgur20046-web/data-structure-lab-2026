#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "graph.h"

// 전방 선언 (헤더에서는 포인터만 쓰므로 #include 없이 선언만)
class QLabel;
class QVBoxLayout;
class MapWidget;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Graph        graph;                      // 그래프 자료구조 (MainWindow가 보유)
    MapWidget*   mapWidget   = nullptr;      // 지도 + 노드 위젯
    QLabel*      titleLabel  = nullptr;      // 오른쪽 상단 (선택 공항 이름)
    QLabel*      hintLabel   = nullptr;      // 오른쪽 안내문
    QVBoxLayout* infoLayout  = nullptr;      // 오른쪽 항공편 목록 영역

    void buildGraph();                              // 1) 그래프 데이터 구성
    void buildUI();                                 // 2) 화면(UI) 구성
    void showAirport(int v);                        // 공항 클릭 -> 출발/도착편 표시
    void bookFlight(int fromIndex, const Flight& f);// 항공편 클릭 -> 예매
    void clearInfo();                               // 오른쪽 목록 비우기
    QString priceText(int won) const;               // 가격을 "₩85,000" 형태로
    QString timeText(int minutes) const;            // 분을 "1시간 0분" 형태로
};

#endif // MAINWINDOW_H
