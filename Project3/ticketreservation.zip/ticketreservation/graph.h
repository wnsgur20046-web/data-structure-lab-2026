#ifndef GRAPH_H
#define GRAPH_H

#include <QString>
#include <vector>
#include <utility>

// ============================================================
//   그래프 자료구조 (인접 리스트 / Adjacency List)
//   - Flight  : 간선(Edge) = 항공편
//   - Airport : 정점(Vertex) = 공항 (지도 표시용 위도/경도 포함)
//   - Graph   : 위 둘을 모아 관리하는 그래프 본체
// ============================================================

// [간선 Edge] 한 공항 -> 다른 공항으로 가는 항공편 하나
class Flight {
public:
    int     to;        // 도착 공항의 노드 인덱스
    QString flightNo;  // 항공편 번호
    QString airline;   // 항공사
    int     price;     // 가격 (간선의 가중치 1)
    int     minutes;   // 소요 시간(분) (간선의 가중치 2)

    Flight(int to_, QString flightNo_, QString airline_, int price_, int minutes_)
        : to(to_), flightNo(flightNo_), airline(airline_),
          price(price_), minutes(minutes_) {}
};

// [정점 Vertex] 공항 하나. 출발 항공편 목록(인접 리스트) + 지도 좌표를 가짐
class Airport {
public:
    QString code;                 // 공항 코드 (예: "ICN")
    QString name;                 // 공항 이름 (예: "인천")
    double  lat;                  // 위도 (지도 위치 계산용)
    double  lon;                  // 경도
    int     nudgeX;               // 노드가 겹칠 때 화면상 미세 조정(px)
    int     nudgeY;
    std::vector<Flight> flights;  // 인접 리스트: 이 공항에서 출발하는 항공편들

    Airport() : lat(0), lon(0), nudgeX(0), nudgeY(0) {}
    Airport(QString code_, QString name_, double lat_, double lon_, int nx, int ny)
        : code(code_), name(name_), lat(lat_), lon(lon_), nudgeX(nx), nudgeY(ny) {}
};

// [그래프 Graph] 공항(노드)들을 모아 관리
class Graph {
public:
    // 노드(공항) 추가 — 추가 순서가 곧 인덱스
    void addAirport(QString code, QString name, double lat, double lon,
                    int nudgeX = 0, int nudgeY = 0) {
        airports.push_back(Airport(code, name, lat, lon, nudgeX, nudgeY));
    }

    // 간선(항공편) 추가 — from 공항의 인접 리스트에 넣음
    void addFlight(int from, int to, QString flightNo,
                   QString airline, int price, int minutes) {
        airports[from].flights.push_back(
            Flight(to, flightNo, airline, price, minutes));
    }

    int size() const { return static_cast<int>(airports.size()); }
    const Airport& at(int index) const { return airports[index]; }

    // v 공항으로 '들어오는' 항공편(도착편) 목록을 모아서 반환
    // 모든 노드의 간선을 훑어 to == v 인 것을 찾는다 (역방향 탐색)
    std::vector<std::pair<int, Flight> > arrivalsTo(int v) const {
        std::vector<std::pair<int, Flight> > result;
        for (int u = 0; u < size(); ++u)
            for (const Flight& f : airports[u].flights)
                if (f.to == v)
                    result.push_back(std::make_pair(u, f));
        return result;
    }

private:
    std::vector<Airport> airports;   // 그래프 전체 = 공항 배열 (인접 리스트 표현)
};

#endif // GRAPH_H
